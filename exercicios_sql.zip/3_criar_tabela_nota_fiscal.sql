CREATE TABLE Nota_Fiscal (
    Numero_NF INTEGER PRIMARY KEY,
    Data_NF DATE,
    Valor_NF FLOAT
);